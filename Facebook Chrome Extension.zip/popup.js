
(function(){

	window.addEventListener('load', function() {
		//alert('Please do not press that button again.');
	});

})();